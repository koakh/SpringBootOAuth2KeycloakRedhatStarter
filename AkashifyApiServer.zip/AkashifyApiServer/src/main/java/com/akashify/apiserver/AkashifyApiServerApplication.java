package com.akashify.apiserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AkashifyApiServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AkashifyApiServerApplication.class, args);
	}
}
